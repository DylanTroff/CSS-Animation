//De achtergrond//

var nico = document.querySelector(".nico");
nico.addEventListener("click", ikbenargentijns);

function ikbenargentijns() {
    document.body.classList.toggle("argentijn");  
}

//DE BEWEGING EN GELUID

var hetGeuid = document.querySelector("audio");


var stopbutton = document.querySelector(".buttonaan");
stopbutton.addEventListener("click", bewegen);

function bewegen(){
    document.body.classList.add("lopen");
    hetGeuid.play(); 
}

var stopbutton = document.querySelector(".buttonuit");
stopbutton.addEventListener("click", stopbewegen);

function stopbewegen(){
    document.body.classList.remove("lopen");
    hetGeuid.pause(); 
}


